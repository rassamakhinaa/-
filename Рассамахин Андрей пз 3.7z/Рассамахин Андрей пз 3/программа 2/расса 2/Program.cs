﻿// @1_@1.cs - первая программа
using static System.Console;
class HelloUser
{
    static void Main()
    {
        string name;
        WriteLine("Введите Ваше имя: ");
        name = ReadLine();
        WriteLine("Приветствую Bac, “ + name + "!");
        WriteLine("/infl завершения сеанса нажмите ENTER.");
        ReadLine();
    }
}

