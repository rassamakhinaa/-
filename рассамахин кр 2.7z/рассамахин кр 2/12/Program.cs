﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите число:");
            double n = Convert.ToInt32(Console.ReadLine());
            double sum = 0;
            for (int i = 0; i <= n; i ++)
            {
                sum += Math.Pow(2,i);
            }
            Console.WriteLine(sum);
            Console.ReadKey();
        }
    }
}
